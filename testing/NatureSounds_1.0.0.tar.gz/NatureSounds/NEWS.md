# NEWS

# NatureSound 1.0.0
##### (Release date: 2018-08-28)

* First release
