# *NatureSound 1.0.2*

* Vignette describing data sets was added.

* 'thyroptera.est' example data: extended selection table (in warbleR package format) containing annotation and acoustic data of Spix's disc-winged bat social calls. 

* 'monk.parakeet.est' example data: extended selection table (in warbleR package format) containing annotation and acoustic data of monk parakeet contact calls. 

# *NatureSound 1.0.1*

* 'Phae.long.est' example data: extended selection table (in warbleR package format) containing annotation and acoustic data of long-billed hermit vocalizations. 


# *NatureSound 1.0.0*

* First release
